const ADMIN_PASSWORD = "admin123"; // DEMO ONLY — not secure authentication.

const state = {
  user: localStorage.getItem("ar_user") || "",
  players: JSON.parse(localStorage.getItem("ar_players") || "[]"),
  requests: JSON.parse(localStorage.getItem("ar_requests") || "[]")
};

const $ = id => document.getElementById(id);
const save = () => {
  localStorage.setItem("ar_user", state.user);
  localStorage.setItem("ar_players", JSON.stringify(state.players));
  localStorage.setItem("ar_requests", JSON.stringify(state.requests));
};

function currentPlayer(){
  return state.players.find(p => p.username === state.user);
}
function ensurePlayer(username){
  let p = state.players.find(x => x.username === username);
  if(!p){
    p = {username, passwordHash: btoa($("password")?.value || ""), credits:0, created:new Date().toISOString()};
    state.players.push(p);
  }
  return p;
}
function show(view){
  ["loginView","lobbyView","accountView","adminView"].forEach(x => $(x).classList.toggle("hidden", x !== view));
  document.querySelectorAll(".nav-btn").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  updateUI();
}
function updateUI(){
  const p = currentPlayer();
  $("balance").textContent = p ? p.credits.toLocaleString() : "0";
  $("accountName").textContent = p?.username || "—";
  $("accountBalance").textContent = p ? p.credits.toLocaleString() : "0";
  $("requestCount").textContent = state.requests.filter(r=>r.username===state.user).length;
  renderAdmin();
}
function openModal(title, body){
  $("modalTitle").textContent = title;
  $("modalBody").innerHTML = body;
  $("modal").classList.remove("hidden");
}
$("closeModal").onclick = () => $("modal").classList.add("hidden");

$("loginForm").onsubmit = e => {
  e.preventDefault();
  const username = $("username").value.trim();
  const password = $("password").value;
  if(!username || !password) return;
  const existing = state.players.find(p=>p.username===username);
  if(existing && existing.passwordHash !== btoa(password)){
    openModal("Login failed","That username already exists with a different password.");
    return;
  }
  state.user = username;
  const p = existing || {username, passwordHash:btoa(password), credits:0, created:new Date().toISOString()};
  if(!existing) state.players.push(p);
  save(); show("lobbyView");
};
$("logoutBtn").onclick = () => { state.user=""; save(); show("loginView"); };
document.querySelectorAll(".nav-btn[data-view]").forEach(btn => btn.onclick = () => show(btn.dataset.view === "account" ? "accountView" : "lobbyView"));
$("backLobbyBtn").onclick = () => show("lobbyView");

$("adminBtn").onclick = () => {
  if(!state.user){ openModal("Sign in required","Sign in first to open the admin panel."); return; }
  openModal("Admin password", `<label>Password<input id="adminPassword" type="password" autofocus></label><button class="primary wide" style="margin-top:15px" id="adminLogin">Open Admin Panel</button>`);
  setTimeout(()=> {
    $("adminLogin").onclick = () => {
      if($("adminPassword").value === ADMIN_PASSWORD){ $("modal").classList.add("hidden"); show("adminView"); }
      else openModal("Incorrect password","For this demo, the admin password is <b>admin123</b>.");
    };
  },0);
};

$("requestCreditsBtn").onclick = () => {
  if(!state.user) return;
  const pending = state.requests.find(r=>r.username===state.user && r.status==="Pending");
  if(pending){ openModal("Request already pending","You already have a pending credit request."); return; }
  state.requests.push({id:Date.now(),username:state.user,amount:100,status:"Pending",created:new Date().toISOString()});
  save(); updateUI();
  openModal("Request submitted","A demo request for <b>100 virtual credits</b> was added to the Admin → Orders section.");
};

document.querySelectorAll(".game-card").forEach(c => c.onclick = () => openGame(c.dataset.game));

function requireCredits(amount){
  const p=currentPlayer();
  if(!p || p.credits < amount){ openModal("Not enough credits","Use <b>Request Credits</b> and approve the request from the Admin panel."); return false; }
  return true;
}
function spend(amount){ currentPlayer().credits -= amount; save(); updateUI(); }
function earn(amount){ currentPlayer().credits += amount; save(); updateUI(); }

function openGame(game){
  const area=$("gameArea"); area.classList.remove("hidden");
  if(game==="roulette") area.innerHTML = rouletteHTML();
  if(game==="slots") area.innerHTML = slotsHTML();
  if(game==="blackjack") area.innerHTML = blackjackHTML();
  if(game==="dice") area.innerHTML = diceHTML();
  area.scrollIntoView({behavior:"smooth",block:"start"});
  bindGame(game);
}
const betHTML = `<label>Bet<input class="bet" type="number" min="1" value="10"></label>`;

function rouletteHTML(){return `<div class="game-head"><h2>🎡 Roulette</h2><span class="muted">Red / black / green 0</span></div><div class="roulette"><div class="wheel" id="wheel"><span id="wheelNum">?</span></div><div class="controls">${betHTML}<select id="roulettePick"><option value="red">Red</option><option value="black">Black</option><option value="green">0</option></select><button class="primary" id="spinBtn">Spin</button></div><div class="result" id="gameResult"></div></div>`}
function slotsHTML(){return `<div class="game-head"><h2>🎰 Slots</h2><span class="muted">Match symbols for prizes</span></div><div class="slots"><div class="reel" id="r1">🍒</div><div class="reel" id="r2">⭐</div><div class="reel" id="r3">7️⃣</div></div><div class="controls">${betHTML}<button class="primary" id="spinSlots">Spin</button></div><div class="result" id="gameResult"></div>`}
function diceHTML(){return `<div class="game-head"><h2>🎲 Dice</h2><span class="muted">Guess the roll</span></div><div class="controls">${betHTML}<select id="dicePick"><option value="high">High (8–12)</option><option value="low">Low (2–6)</option><option value="seven">Exact 7</option></select><button class="primary" id="rollDice">Roll</button></div><div class="result" id="gameResult"></div>`}
function blackjackHTML(){return `<div class="game-head"><h2>🃏 Blackjack</h2><span class="muted">Beat the dealer without going over 21</span></div><div id="bjBoard"><div class="result">Click Deal to start.</div></div><div class="controls">${betHTML}<button class="primary" id="dealBJ">Deal</button><button class="secondary hidden" id="hitBJ">Hit</button><button class="secondary hidden" id="standBJ">Stand</button></div>`}

function bindGame(game){
  if(game==="roulette") bindRoulette();
  if(game==="slots") bindSlots();
  if(game==="dice") bindDice();
  if(game==="blackjack") bindBlackjack();
}
function bindRoulette(){
  $("spinBtn").onclick=()=>{
    const bet=+document.querySelector(".bet").value, pick=$("roulettePick").value;
    if(!Number.isFinite(bet)||bet<1||!requireCredits(bet))return; spend(bet);
    const n=Math.floor(Math.random()*37), red=[1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
    const color=n===0?"green":red.includes(n)?"red":"black";
    $("wheel").style.transform=`rotate(${720+Math.random()*720}deg)`;
    setTimeout(()=>{$("wheelNum").textContent=n;$("gameResult").textContent=pick===color?`You won ${pick==="green"?bet*35:bet*2} credits!`:`${n} ${color} — you lost ${bet} credits.`; if(pick===color)earn(pick==="green"?bet*35:bet*2)},2000);
  };
}
function bindSlots(){
  $("spinSlots").onclick=()=>{
    const bet=+document.querySelector(".bet").value;if(!Number.isFinite(bet)||bet<1||!requireCredits(bet))return;spend(bet);
    const syms=["🍒","🍋","⭐","🔔","💎","7️⃣"], reels=[$("r1"),$("r2"),$("r3")];
    const vals=reels.map(r=>syms[Math.floor(Math.random()*syms.length)]);
    reels.forEach((r,i)=>setTimeout(()=>r.textContent=vals[i],i*250));
    setTimeout(()=>{let win=vals.every(v=>v===vals[0])?bet*10:vals.filter(v=>v==="7️⃣").length===2?bet*4:vals.filter(v=>v==="💎").length===2?bet*3:0;if(win)earn(win);$("gameResult").textContent=win?`Jackpot! +${win} credits.`:`No match — ${bet} credits spent.`},800);
  };
}
function bindDice(){
  $("rollDice").onclick=()=>{
    const bet=+document.querySelector(".bet").value,pick=$("dicePick").value;if(!Number.isFinite(bet)||bet<1||!requireCredits(bet))return;spend(bet);
    const n=2+Math.floor(Math.random()*11); let win=(pick==="seven"&&n===7)||(pick==="high"&&n>=8)||(pick==="low"&&n<=6); if(win){let mult=pick==="seven"?5:2;earn(bet*mult);$("gameResult").textContent=`You rolled ${n}. +${bet*mult} credits!`}else $("gameResult").textContent=`You rolled ${n}. You lost ${bet} credits.`;
  };
}
let bj={player:[],dealer:[]};
const cards=["A","2","3","4","5","6","7","8","9","10","J","Q","K"];
function card(){return cards[Math.floor(Math.random()*cards.length)]}
function val(hand){let total=0,aces=0;for(const c of hand){if(c==="A"){aces++;total+=11}else total+=["K","Q","J"].includes(c)?10:+c}while(total>21&&aces){total-=10;aces--}return total}
function bindBlackjack(){
  $("dealBJ").onclick=()=>{const bet=+document.querySelector(".bet").value;if(!Number.isFinite(bet)||bet<1||!requireCredits(bet))return;spend(bet);bj={player:[card(),card()],dealer:[card(),card()]};renderBJ();$("dealBJ").classList.add("hidden");$("hitBJ").classList.remove("hidden");$("standBJ").classList.remove("hidden");if(val(bj.player)===21)finishBJ(bet)};
  $("hitBJ").onclick=()=>{bj.player.push(card());renderBJ();const v=val(bj.player);if(v>=21)finishBJ(+document.querySelector(".bet").value)};
  $("standBJ").onclick=()=>finishBJ(+document.querySelector(".bet").value);
}
function renderBJ(){ $("bjBoard").innerHTML=`<div class="cards">${bj.player.map(c=>`<div class="playing-card">${c}</div>`).join("")}</div><div class="muted">You: ${val(bj.player)}</div><div class="cards">${bj.dealer.map((c,i)=>`<div class="playing-card">${i===0?"?":c}</div>`).join("")}</div><div class="muted">Dealer: ?</div>`}
function finishBJ(bet){while(val(bj.dealer)<17)bj.dealer.push(card());const p=val(bj.player),d=val(bj.dealer);let payout=p>21?0:d>21||p>d?bet*2:p===d?bet:0;if(payout)earn(payout);$("bjBoard").innerHTML=`<div class="cards">${bj.player.map(c=>`<div class="playing-card">${c}</div>`).join("")}</div><div class="muted">You: ${p}</div><div class="cards">${bj.dealer.map(c=>`<div class="playing-card">${c}</div>`).join("")}</div><div class="muted">Dealer: ${d}</div><div class="result">${payout===bet?"Push — your bet was returned.":payout?`You win +${payout} credits!`:`Dealer wins.`}</div>`;$("hitBJ").classList.add("hidden");$("standBJ").classList.add("hidden");$("dealBJ").classList.remove("hidden");}

function renderAdmin(){
  const players=state.players, requests=state.requests;
  $("playerStat").textContent=players.length;
  $("pendingStat").textContent=requests.filter(r=>r.status==="Pending").length;
  $("creditsStat").textContent=players.reduce((a,p)=>a+p.credits,0).toLocaleString();
  $("playersTable").innerHTML=players.length?`<table><thead><tr><th>Player</th><th>Credits</th><th>Action</th></tr></thead><tbody>${players.map((p,i)=>`<tr><td>${escapeHTML(p.username)}</td><td>${p.credits.toLocaleString()}</td><td><button class="action" onclick="adjustCredits(${i})">Adjust</button></td></tr>`).join("")}</tbody></table>`:"<p class='muted'>No players yet.</p>";
  $("ordersTable").innerHTML=requests.length?`<table><thead><tr><th>Player</th><th>Request</th><th>Status</th><th>Action</th></tr></thead><tbody>${requests.map((r,i)=>`<tr><td>${escapeHTML(r.username)}</td><td>${r.amount} credits</td><td>${r.status}</td><td>${r.status==="Pending"?`<button class="action" onclick="approveRequest(${i})">Approve</button> <button class="action" onclick="denyRequest(${i})">Deny</button>`:"—"}</td></tr>`).join("")}</tbody></table>`:"<p class='muted'>No requests/orders yet.</p>";
}
function adjustCredits(i){const amount=prompt("Enter the new credit balance for "+state.players[i].username,state.players[i].credits);if(amount!==null&&Number.isFinite(+amount)&&+amount>=0){state.players[i].credits=Math.floor(+amount);save();updateUI();}}
function approveRequest(i){const r=state.requests[i],p=state.players.find(x=>x.username===r.username);if(!p)return;r.status="Approved";p.credits+=r.amount;save();updateUI();}
function denyRequest(i){state.requests[i].status="Denied";save();updateUI();}
function escapeHTML(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

if(state.user && currentPlayer()) show("lobbyView"); else show("loginView");
