# Arcade Royale — Virtual Credits Demo

A free, static HTML/CSS/JavaScript browser game.

## Included
- Username/password sign-in (demo/local only)
- New players start at 0 virtual credits
- Roulette
- Slots
- Blackjack
- Dice
- Credit request flow
- Admin panel with password prompt
- Player balances
- Orders/credit requests
- Local browser storage

## Demo admin password
`admin123`

Change `ADMIN_PASSWORD` in `app.js` before sharing the demo.

## Important
This is a client-side demo. Passwords, balances, requests, and the admin password are stored in the browser and are NOT secure. GitHub Pages is static hosting and cannot provide a secure database or server-side authentication. Do not use this code for real-money gambling, real payments, or sensitive account data.

## Run locally
Double-click `index.html` or open it in a browser.

## GitHub Pages
1. Create a public GitHub repository.
2. Upload `index.html`, `style.css`, `app.js`, and this README.
3. Open repository Settings → Pages.
4. Under Build and deployment, choose "Deploy from a branch".
5. Choose `main` and `/ (root)`, then Save.
6. Wait for deployment and click "Visit site".
